

////////////////// Cascading Control /////////////////////////

function Cascade(parent, child, additionalparentval, controllername, parentactionname, childactionname, parentval, childval, controltypeCode, grandparentval) {
    var controltype = "";
    if (controltypeCode.toLowerCase() == "d")
        controltype = "kendoDropDownList";
    else if (controltypeCode.toLowerCase() == "c")
        controltype = "kendoComboBox";

    //alert(childval);
    $("#" + parent).change(function () {
        cascadechild(parent, child, additionalparentval, controllername, childactionname, 0, controltype);
    });


    $.ajax({
        type: "GET",
        url: '/' + controllername + '/' + parentactionname + '/' + grandparentval,
        success: function (resultlist) {
            var parentlist = $("#" + parent);
            parentlist.empty();
            parentlist.data(controltype).dataSource.data([]);
            parentlist.val("").data(controltype).text("");

            parentlist.data(controltype).dataSource.data(resultlist);

            if (parentval > 0) {
                $("#" + parent).data(controltype).value(parentval);
                cascadechild(parent, child, additionalparentval, controllername, childactionname, childval, controltype);
            }

            if (controltype == "kendoComboBox")
                resetifwrong(parent);
        }
    });
}


function cascadechild(parent, child, additionalparentval, controllername, childactionname, childval, controltype) {
    //alert('parent : ' + parent + ',child : ' + child + ', childval : ' + childval);
    var parentvalue = $("#" + parent).data(controltype).value();

    if ($.trim(additionalparentval).length > 0) {
        var additionalparentvalue = $("#" + additionalparentval).val().toString();
        parentvalue = parentvalue + '~' + additionalparentvalue;
    }


    $.ajax({
        type: "GET",
        url: "/" + controllername + "/" + childactionname + "/" + parentvalue,
        success: function (resultData) {
            var childlist = $("#" + child);
            childlist.empty();
            childlist.data(controltype).dataSource.data([]);
            childlist.val("").data(controltype).text("");

            childlist.data(controltype).dataSource.data(resultData);

            if (childval > 0)
                $("#" + child).data(controltype).value(childval);

            if (controltype == "kendoComboBox")
                resetifwrong(child);
        }
    });
}



//////////////////////


function CascadeMultiple(parent, childs, additionalparentval, controllername, parentactionname, childactionnames, parentval, childvals, controltypeCode, grandparentval) {

    var controltype = "";
    if (controltypeCode.toLowerCase() == "d")
        controltype = "kendoDropDownList";
    else if (controltypeCode.toLowerCase() == "c")
        controltype = "kendoComboBox";

    var childlist = childs.split('~');
    var actionnamelist = childactionnames.split('~');
    var childvallist = childvals.split('~');

    //alert(childval);
    $("#" + parent).change(function () {
        for (var i = 0; i < childlist.length; i++) {
            cascadechild(parent, childlist[i], additionalparentval, controllername, actionnamelist[i], 0, controltype);
        }
    });

    $.ajax({
        type: "GET",
        url: '/' + controllername + '/' + parentactionname + '/' + grandparentval,
        success: function (resultlist) {
            //alert('success : ' + resultlist);
            var parentlist = $("#" + parent);
            parentlist.empty();
            parentlist.data(controltype).dataSource.data([]);
            parentlist.val("").data(controltype).text("");
            var indexlist = '';

            parentlist.data(controltype).dataSource.data(resultlist);

            if (parentval > 0) {
                $("#" + parent).data(controltype).value(parentval);
                for (var i = 0; i < childlist.length; i++) {
                    cascadechild(parent, childlist[i], additionalparentval, controllername, actionnamelist[i], childvallist[i], controltype);
                }
            }
            if (controltype == "kendoComboBox")
                resetifwrong(parent);
        }
    });
}






















///////////////////////// muldiple cascading ////////////////////////////////

function MultipleCascade(parent, multiplechild, additionalparentval, controllername, parentactionname, multiplechildactionname, parentval, childval, controltypeCode, grandparentval) {
    var controltype = "";
    if (controltypeCode.toLowerCase() == "d")
        controltype = "kendoDropDownList";
    else if (controltypeCode.toLowerCase() == "c")
        controltype = "kendoComboBox";

    var result = multiplechild.split('-');
    var actionname = multiplechildactionname.split('-');
    alert(result.length);
    $("#" + parent).change(function () {
        for (var i = 0; i < result.length; i++) {
            alert(result[i]);
            alert(actionname[i]);

            if ($.trim(additionalparentval).length > 0)
                cascadechildop(parent, result[i], additionalparentval, controllername, actionname[i], 0, controltype);
            else
                cascadechild(parent, result[i], controllername, actionname[i], 0, controltype);
        }
    });

    var url = "";

    if ($.trim(grandparentval).length > 0)
        url = '/' + controllername + '/' + parentactionname + '/' + grandparentval;
    else
        url = '/' + controllername + '/' + parentactionname + '/';

    //alert(url);

    $.ajax({
        type: "GET",
        url: url,
        success: function (resultlist) {
            var parentlist = $("#" + parent);
            parentlist.empty();
            parentlist.data(controltype).dataSource.data([]);
            parentlist.val("").data(controltype).text("");

            $.each(resultlist, function (index, itemData) {
                parentlist.data(controltype).dataSource.add({ Text: itemData.Text, Value: itemData.Value });
            });

            if (parentval == 0)
                $("#" + parent).data(controltype).value(parentval);

            if (parentval > 0) {
                //alert(parentval);
                $("#" + parent).data(controltype).value(parentval);

                if ($.trim(additionalparentval).length > 0)
                    cascadechildop(parent, child, additionalparentval, controllername, childactionname, childval, controltype);
                else
                    cascadechild(parent, child, controllername, childactionname, childval, controltype);
            }
        }
    });
}








