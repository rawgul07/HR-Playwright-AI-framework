///////// Report User Log ////////////

$('input[type="button"][data-reporttitle]').live('click', function () {
  
    $.ajax({
        type: "POST",
        url: "Home/SaveUserLog",
        data: { title: $(this).data('reporttitle'), type: $(this).data('actiontype'), logtype: 1 },
        dataType: "json",
        error: function (response) {
            alert("Try Again ...");
        }
    });
});

///////// Menu User Log ////////////
function menuuserlog(_title) {
    console.log(_title);
    $.ajax({
        type: "POST",
        url: "Home/SaveUserLog",
        data: { title: _title, type: 100, logtype: 2 },
        dataType: "json",
        error: function (response) {
            alert("Try Again ...");
        }
    });

}

/////////////// Export to Excel ///////////////

$('a[data-reporttitle]').live('click', function () {
    
    $.ajax({
        type: "POST",
        url: "Home/SaveUserLog",
        data: { title: $(this).data('reporttitle'), type: $(this).data('actiontype'), logtype: 1 },
        dataType: "json",
        error: function (response) {
            alert("Try Again ...");
        }
    });
});


