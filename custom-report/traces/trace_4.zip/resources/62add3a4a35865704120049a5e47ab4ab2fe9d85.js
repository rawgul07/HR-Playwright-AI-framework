


/* Save Report Query String */

function savereportquerystring(str) {

    var tickDate = new Date().getTime().toString();

    $.each(str.match(/(.|[\r\n]){1,2500000}/g), function (i, v) {

        var jsonText = "";
        jsonText = JSON.stringify(v);

        $.ajax({
            url: 'Home/SaveReportQueryString',
            type: "POST",
            data: { _jsonText: jsonText, key: tickDate, order: i },
            datatype: "html",
            async: false,
            success: function (data) {
            },
            error: function (data) { alert("Please Refresh Your Browser and Do the Process Again ... "); }
        });

    });

    return '-' + tickDate;
}

/* Set Grid Height in All Index Page*/

function setgridheight(isinline) {
    var width = $(window).width(), height = $(window).height();
    var x = $(".k-grouping-header").offset();
    var BottomSpace = 0;
    if (!isinline)
        BottomSpace = 180;
    else {
        BottomSpace = 212;
    }
    if (height > 850) {
        $(".IndexGrid").css({ "height": ((height - x.top) - 86), "min-height": "250px !important" });
        $(".k-grid-content").css({ "height": ((height - x.top) - BottomSpace), "min-height": ((height - x.top) - BottomSpace) });
    }
    else {
        $(".IndexGrid").css({ "height": (700 - 86), "min-height": "250px !important" });
        $(".k-grid-content").css({ "height": (700 - BottomSpace), "min-height": (500 - BottomSpace) });
    }
}
/*  

content_attr_type : byId,byClass,byObject
*/
function postData(controller_name, action_name, param_val, content_section, success_message) {
    $("#" + content_section).html(showloadingmsg('Please wait...'));
    $("." + content_section).html(showloadingmsg('Please wait...'));
    $.ajax({
        type: "POST",
        url: '/' + controller_name + '/' + action_name + '/',
        data: { ParamValue: param_val },
        dataType: "json",
        success: function (result) {
            $("#" + content_section).html(showsuccessmsg(success_message));
            $("." + content_section).html(showsuccessmsg(success_message));

            setTimeout("$('#" + content_section + "').html('')", 1200);
            setTimeout("$('." + content_section + "').html('')", 1200);
            //if (!(typeof onCompletepostData === 'undefined')) {
            onCompletepostData(result);
            //}
        },
        error: function () {
            alert('Error Occured!!! Please contact administrator!!!');
        }

    });
}


function showsuccessmsg(msg) {
    return "<div style='padding: 5px;background-color:#a4d8a0'>" + msg + "</div>";
}

function showloadingmsg(msg) {
    return "<div style='padding: 5px;background-color:#fcfbcf'>" + msg + "</div>";
}

function showerrormsg(msg) {
    return "<div style='padding: 5px;background-color:#f2dfdf'>" + msg + "</div>";
}


function callPartialView(controller_name, action_name, param_val, content_section, partial_view, content_attr_type) {
    //alert(1);
    $.ajax({
        url: '/' + controller_name + '/' + action_name + '/',
        cache: false,
        beforeSend: function () {
            var loadingcontent = "<div>Loading... Please wait...</div>";
            switch (content_attr_type) {
                case 'byId':
                    $('#' + content_section).html(loadingcontent);
                    break;
                case 'byClass':
                    $('.' + content_section).html(loadingcontent);
                    break;
                case 'byObject':
                    $(content_section).html(loadingcontent);
                    break;
            }
        },
        complete: function () {
            //   $('.ajaxloader').hide();
        },
        contentType: 'application/html; charset=utf-8',
        type: 'GET',
        dataType: 'html',
        data: { ParamValue: param_val, PartialViewName: partial_view }
    })
            .success(function (result) {
                //alert(result);
                var dom = $(result);
                //alert(dom);
                switch (content_attr_type) {
                    case 'byId':
                        //alert($('#' + content_section));
                        $('#' + content_section).html(dom);
                        break;
                    case 'byClass':
                        $('.' + content_section).html(dom);
                        break;
                    case 'byObject':
                        $(content_section).html(dom);
                        break;
                }

                $('form').removeData('validator');
                $('form').removeData('unobtrusiveValidation');
                $.validator.unobtrusive.parse('form');
                $.validator.unobtrusive.parse(document);

            })
            .error(function (xhr, status) {
                alert(xhr.responseText);
                var dom = $(xhr.responseText);
                switch (content_attr_type) {
                    case 'byId':
                        $('#' + content_section).html(dom);
                        break;
                    case 'byClass':
                        $('.' + content_section).html(dom);
                        break;
                    case 'byObject':
                        $(content_section).html(dom);
                        break;
                }

            });
}



function callPartialViewContent(controller_name, action_name, param_val, partial_view, resultcallbackfn) {
    //alert(1);
    $.ajax({
        url: '/' + controller_name + '/' + action_name + '/',
        cache: false,
        contentType: 'application/html; charset=utf-8',
        type: 'GET',
        dataType: 'html',
        data: { ParamValue: param_val, PartialViewName: partial_view }
    })
            .success(function (result) {
                //alert(result);
                var dom = $(result);
                resultcallbackfn(dom);

                $('form').removeData('validator');
                $('form').removeData('unobtrusiveValidation');
                $.validator.unobtrusive.parse('form');
                $.validator.unobtrusive.parse(document);

            })
            .error(function (xhr, status) {
                alert(xhr.responseText);
                var dom = $(xhr.responseText);
                resultcallbackfn(dom);
            });
}

function prepare_ccddl(parentddl, childddl, controllername, actionname, isaddempty) {
    $("#" + parentddl).live('change', function () {

        var idModel = $(this).val().toString();
        $.getJSON("/" + controllername + "/" + actionname + "/" + idModel,
                    function (ddlData) {
                        var select = $("#" + childddl);
                        select.empty();
                        var ds = select.data().kendoDropDownList.dataSource;
                        select.data("kendoDropDownList").dataSource.data([]);
                        select.val("").data("kendoDropDownList").text("");
                        $.each(ddlData, function (index, itemData) {
                            select.data("kendoDropDownList").dataSource.add({ text: itemData.Text, value: itemData.Value });
                        });
                        if (!isaddempty) {
                            select.select(1);
                        }
                    });
    });
}


function prepare_ccddlop(parentddl, childddl, optionalddl, controllername, actionname, isaddempty) {
    $("#" + parentddl).live('change', function () {

        var idModel = $(this).val().toString();
        var optionid = $("#" + optionalddl).val().toString();
        var paramvalue = idModel + '-' + optionid;
        $.getJSON("/" + controllername + "/" + actionname + "/" + paramvalue,
                    function (ddlData) {
                        var select = $("#" + childddl);
                        select.empty();
                        var ds = select.data().kendoDropDownList.dataSource;
                        select.data("kendoDropDownList").dataSource.data([]);
                        select.val("").data("kendoDropDownList").text("");
                        $.each(ddlData, function (index, itemData) {
                            select.data("kendoDropDownList").dataSource.add({ text: itemData.Text, value: itemData.Value });
                        });

                        if (!isaddempty) {
                            select.select(1);
                        }
                    });
    });
}

var ONE_DAY = 1000 * 60 * 60 * 24;
var ONE_HOUR = 1000 * 60 * 60;
var ONE_MIN = 1000 * 60;


function datetimediff(fromtb, totb, result) {
    $("#" + fromtb).live('change', function () {
        var fromval = $(this).val();
        var toval = $("#" + totb).val();

        getdiffval(fromval, toval, result);
    });

    $("#" + totb).live('change', function () {
        var fromval = $("#" + fromtb).val();
        var toval = $(this).val();

        getdiffval(fromval, toval, result);
    });

    var fromval = $("#" + fromtb).val();
    var toval = $("#" + totb).val();
    getdiffval(fromval, toval, result);

}

function getdiffval(_start, _end, result) {
    $.getJSON("/Home/GetDateTimeDiff", { start: _start, end: _end },
                    function (data) {
                        $("#" + result).text(data);
                    });

    //    var diff = new Date(Date.parse(end) - Date.parse(start));
    //    var days = Math.round(diff / ONE_DAY);   
    //    if (isNaN(days))
    //        return "-";
    //    var hours = Math.round(diff / ONE_HOUR) - (days * 24);
    //    var mins = Math.round(diff / ONE_MIN) - ((days * 24 * 60) + (hours * 60));
    //    return days + " Day(s) " + hours + " Hour(s) " + mins + " Min(s)";
}

function handle_kgrid_error(gridid, e) {
    var valueit = "true";
    var grid = $("#" + gridid).data("kendoGrid");

    var message = "<b>Alert:</b><br><br>";
    if (e.errors) {
        grid.cancelChanges();
        $.each(e.errors, function (key, value) {

            if ('errors' in value) {
                $.each(value.errors, function (k, v) {

                    if (v.length > 0) {
                        message += "<span style='color:Red'> " + v + "</span><br>";
                        if (v == "0") {
                            valueit = "false";
                        }
                    }
                });
            }
        });

        if (valueit == "true") {
            $("#errordiv").html(message);
            $("#errordialog").dialog("open");
        }

        return true;

    }
    else {

        return false;
    }
}

function initialize_k_validation(validator, buttonid) {
    var status = $(".error");
    $("#" + buttonid).die('click');
    $("#" + buttonid).live('click', function () {

        $("input[type=submit]").attr("disabled", "disabled").addClass("k-state-disabled").removeClass("k-state-focused");

        if (validator.validate()) {
            status.html("");
            //         
            //            alert(navigator.userAgent);
            //            alert(navigator.userAgent.toLowerCase().indexOf('firefox'));

            //            if ((navigator.userAgent.toLowerCase().indexOf('mozilla') >= 0) || (navigator.userAgent.toLowerCase().indexOf('firefox') >= 0)) { // firefox
            //                alert('ff')
            //            }
            if ((navigator.userAgent.toLowerCase().indexOf('chrome') >= 0))
                $(this).parents('form').submit();
        } else {

            status.html("Oops! There is invalid data in the form.").addClass("error");

            $("input[type=submit]").removeAttr("disabled").removeClass("k-state-disabled");
        }

    });

    $("span.k-dropdown").change(function () {
        var ddldiv = $(this).closest('div');
        var validator = ddldiv.kendoValidator().data("kendoValidator");
        validator.validate();
    });

    $.each($("span.k-combobox"), function (index, value) {
        resetifwrong($(this).closest('div').find("input[data-role='combobox']").attr('id'));
    });

    $("span.k-combobox").change(function () {
        resetifwrong($(this).closest('div').find("input[data-role='combobox']").attr('id'));
        var cbdiv = $(this).closest('div');
        var validator = cbdiv.kendoValidator().data("kendoValidator");
        validator.validate();
    });

}

function resetifwrong(comboboxid) {
    //alert("reset");
    var isreset = false;
    var combotext = $("#" + comboboxid).data('kendoComboBox').text();
    var combovalue = $("#" + comboboxid).data('kendoComboBox').value();
    var data = $("#" + comboboxid).data("kendoComboBox").dataSource.data();

    $.each(data, function (index, itemData) {
        if (itemData.Text == combotext && combovalue != 0)
            isreset = true;
    });

    //alert(isreset);
    if (isreset == false)
        $("#" + comboboxid).data('kendoComboBox').text('');
}

function ScrollToFailureMessgae() {
    //alert($('.tabstripFailure').offset().top);
    //alert($(this).closest('.ui-dialog').attr('class'));
    //alert($(".verticalpad").html() === null);
    if ($(".verticalpad").html() === null) {
        $('html, body').animate({
            scrollTop: $('.tabstripFailure').offset().top
        }, 700);
    }
    else {
        $(window).scrollTop(0);
        $('.ui-dialog-content').animate({
            scrollTop: 0
        }, 700);
    }
}



function parseThisYourVeryKnownFormatToDate(dateString /* '12/Jun/2010' */) {
    function getMonthIdx(monthName) {
        var months = {
            'Jan': 0, 'Feb': 1, 'Mar': 2, 'Apr': 3, 'May': 4, 'Jun': 5
      , 'Jul': 6, 'Aug': 7, 'Sep': 8, 'Oct': 9, 'Nov': 10, 'Dec': 11
        };
        return months[monthName];
    }
    var format = /^(\d+)\/(\w{3})\/(\d{4})$/;
    var match = format.exec(dateString);
    if (!match) { return undefined; }
    var day = match[1], monthIdx = getMonthIdx(match[2]), year = match[3];
    return new Date(year, monthIdx, day);
}

//////////// Date BIND ///////////////

$(document).ready(function () {
    $(document).off('change', '[data-role="datetimepicker"][data-kdt="1"]').on('change', '[data-role="datetimepicker"][data-kdt="1"]', function (e) {
        setdatetime(this, 'kendoDateTimePicker');
    });

    $(document).off('change', '[data-role="datepicker"][data-kdt="2"]').on('change', '[data-role="datepicker"][data-kdt="2"]', function (e) {
        setdatetime(this, 'kendoDatePicker');
    });

    function setdatetime(ctrl, picker) {

        if ($(ctrl).attr('id').indexOf('kdt_') >= 0) {
            var propname = $(ctrl).data('id');
            var input = $('.tkdt_' + propname);
            var val = $(ctrl).val();
            //alert($(ctrl).val());
            if (val != null) {
                var res = moment(val, 'DD/MM/YYYY').format('MM/DD/YYYY HH:mm:ss');
                //alert(res)
                //    var res = (val.getMonth() + 1) + '/' + val.getDate() + '/' + val.getFullYear() + ' ' + val.getHours() + ':' + val.getMinutes() + ':' + val.getSeconds();
                input.val(res);
                input.valid();
            }
        }
    }
});

function dummycall()
{ }


window.old_alert = window.alert;

window.alert = function (message, fallback) {
    if (fallback) {
        old_alert(message);
        return;
    }
    $(document.createElement('div'))
        .attr({ title: 'Alert', 'class': 'alert' })
        .html(message)
        .dialog({
            buttons: { OK: function () { $(this).dialog('close'); } },
            close: function () { $(this).remove(); },
            draggable: true,
            modal: true,
            resizable: false,
            width: 'auto'
        });
};

/////////////////

//**************************************************Making the Grid 100% high and auto resizable********************************************************************************
//$(window).bind("resize", function () {
//    var gridElement = $("#grid"),
//        newHeight = gridElement.innerHeight(),
//        otherElements = gridElement.children().not(".k-grid-content"),
//        otherElementsHeight = 0;

//    otherElements.each(function () {
//        otherElementsHeight += $(this).outerHeight();
//    });

//    gridElement.children(".k-grid-content").height(newHeight - otherElementsHeight);
//});